from pathlib import Path

from sft.config import DataConfig, ModelConfig, TrainConfig
from sft.model_utils import load_model_for_sft, sync_model_embeddings_with_tokenizer
from sft.pipeline import (
    prepare_data_pipeline,
    prepare_tokenizer_pipeline,
    render_dataset_with_chat_template,
)
from sft.training import build_trainer, build_training_args, train_once


def main() -> None:
    data_cfg = DataConfig()
    model_cfg = ModelConfig()
    train_cfg = TrainConfig()

    prepared_data = prepare_data_pipeline(data_cfg)
    prepared_tokenizer = prepare_tokenizer_pipeline(model_cfg)
    dataset_text = render_dataset_with_chat_template(
        prepared_data.dataset_messages,
        prepared_tokenizer.tokenizer,
    )

    model = load_model_for_sft(model_cfg)
    resized = sync_model_embeddings_with_tokenizer(model, prepared_tokenizer.tokenizer)

    args = build_training_args(
        train_cfg=train_cfg,
        output_dir=f"{train_cfg.output_root}/baseline",
        packing=False,
    )
    trainer = build_trainer(
        model=model,
        tokenizer=prepared_tokenizer.tokenizer,
        train_args=args,
        dataset=dataset_text,
    )
    result = train_once(trainer)

    Path(train_cfg.output_root).mkdir(parents=True, exist_ok=True)
    print("=== READY ===")
    print("tool_stats:", prepared_data.tool_stats)
    print("augmentation_report:", prepared_data.augmentation_report)
    print("resized_embeddings_by:", resized)
    print("eval_loss:", result.eval_loss)
    print("perplexity:", result.perplexity)


if __name__ == "__main__":
    main()
