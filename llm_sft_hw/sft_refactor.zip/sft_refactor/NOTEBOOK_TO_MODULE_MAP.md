# Карта переноса функций из ноутбука

## data.py
- `seed_everything`
- `convert_to_messages`
- `maybe_inject_tool_use`
- `analyze_existing_tool_use`
- `print_tool_analysis` → заменено на `summarize_tool_stats`
- `print_augmentation_stats` → заменено на `build_augmentation_report`
- `build_multi_turn`
- `analyze_tool_use_in_dataset` → объединено с `analyze_existing_tool_use`
- `print_dataset_statistics` → заменено на `build_dataset_report`
- `dataset_to_datasetdict`

## tokenizer_utils.py
- `extract_tool_tokens_from_template`
- `apply_chat_template_map`
- `format_generation_messages`
- `naive_tokenize`
- `inspect_tokenization` → превращено в возвращаемую структуру `inspect_tokenization`

## metrics.py
- `json_validity_rate`
- `json_validity_rate_improved` → стало основной реализацией
- `debug_json_generation`
- `function_call_em`
- `function_call_em_improved` → стало основной реализацией

## visualization.py
- `history_to_dataframe`
- `plot_and_save_line`
- `plot_compare_eval_loss`
- `build_runtime_comparison_table`
- `render_sweep_heatmap`
- `update_results_json_extended`

## training.py / model_utils.py
Функции здесь в ноутбуке были не оформлены как `def`, а лежали кусками в ячейках.
Я вынес их в нормальные функции:

- загрузка модели;
- согласование размера эмбеддингов;
- создание `SFTConfig`;
- создание `SFTTrainer`;
- обучение baseline / packing;
- sweep по LR и accumulation;
- safe-perplexity.
