from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import pandas as pd
from trl import SFTConfig, SFTTrainer
from transformers import TrainerCallback

from .config import SweepConfig, TrainConfig
from .visualization import safe_perplexity


def build_training_args(
    train_cfg: TrainConfig,
    output_dir: str,
    packing: bool,
) -> SFTConfig:
    return SFTConfig(
        output_dir=output_dir,
        num_train_epochs=train_cfg.num_epochs,
        per_device_train_batch_size=train_cfg.batch_size,
        per_device_eval_batch_size=train_cfg.batch_size,
        gradient_accumulation_steps=train_cfg.grad_accum_steps,
        learning_rate=train_cfg.learning_rate,
        lr_scheduler_type=train_cfg.lr_scheduler_type,
        warmup_ratio=train_cfg.warmup_ratio,
        max_grad_norm=train_cfg.max_grad_norm,
        logging_steps=train_cfg.logging_steps,
        save_steps=train_cfg.save_steps,
        eval_steps=train_cfg.eval_steps,
        eval_strategy="steps",
        save_strategy="steps",
        load_best_model_at_end=True,
        report_to=train_cfg.report_to,
        max_length=train_cfg.max_seq_length,
        dataset_text_field="text",
        packing=packing,
    )


def build_trainer(
    model: Any,
    tokenizer: Any,
    train_args: SFTConfig,
    dataset: Any,
    callbacks: list[TrainerCallback] | None = None,
) -> SFTTrainer:
    return SFTTrainer(
        model=model,
        args=train_args,
        train_dataset=dataset["train"],
        eval_dataset=dataset["validation"],
        processing_class=tokenizer,
        callbacks=callbacks or [],
    )


@dataclass(slots=True)
class TrainRunResult:
    train_result: Any
    eval_metrics: dict[str, Any]
    eval_loss: float | None
    perplexity: float | None


def train_once(trainer: SFTTrainer) -> TrainRunResult:
    train_result = trainer.train()
    eval_metrics = trainer.evaluate()
    eval_loss = eval_metrics.get("eval_loss")
    perplexity = safe_perplexity(eval_loss)
    return TrainRunResult(
        train_result=train_result,
        eval_metrics=eval_metrics,
        eval_loss=eval_loss,
        perplexity=perplexity,
    )


def run_sweep(
    model_factory,
    tokenizer: Any,
    dataset: Any,
    base_train_cfg: TrainConfig,
    sweep_cfg: SweepConfig,
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []

    for lr in sweep_cfg.learning_rates:
        for accum in sweep_cfg.accumulation_steps:
            model = model_factory()
            cfg = TrainConfig(
                num_epochs=1,
                learning_rate=lr,
                batch_size=base_train_cfg.batch_size,
                grad_accum_steps=accum,
                max_seq_length=base_train_cfg.max_seq_length,
                warmup_ratio=base_train_cfg.warmup_ratio,
                max_grad_norm=base_train_cfg.max_grad_norm,
                logging_steps=20,
                eval_steps=20,
                save_steps=100,
                lr_scheduler_type=base_train_cfg.lr_scheduler_type,
                report_to=base_train_cfg.report_to,
                output_root=base_train_cfg.output_root,
            )
            args = build_training_args(
                train_cfg=cfg,
                output_dir=f"{cfg.output_root}/sweep_lr{lr}_acc{accum}",
                packing=False,
            )
            trainer = build_trainer(model, tokenizer, args, dataset)
            result = train_once(trainer)
            rows.append(
                {
                    "lr": lr,
                    "accum": accum,
                    "eval_loss": result.eval_loss,
                    "perplexity": result.perplexity,
                    "train_runtime": result.train_result.metrics.get("train_runtime"),
                    "train_steps_per_second": result.train_result.metrics.get("train_steps_per_second"),
                }
            )

    return pd.DataFrame(rows)
