from __future__ import annotations

from typing import Any

import torch
from transformers import AutoModelForCausalLM

from .config import ModelConfig


def load_model_for_sft(cfg: ModelConfig) -> Any:
    kwargs: dict[str, Any] = {
        "trust_remote_code": cfg.trust_remote_code,
        "device_map": "auto",
    }
    if cfg.use_fp16_if_cuda and torch.cuda.is_available():
        kwargs["torch_dtype"] = torch.float16

    model = AutoModelForCausalLM.from_pretrained(cfg.model_name, **kwargs)
    model.gradient_checkpointing_enable()
    model.config.use_cache = False
    return model


def sync_model_embeddings_with_tokenizer(model: Any, tokenizer: Any) -> int:
    vocab_size = len(tokenizer)
    emb_size = model.get_input_embeddings().num_embeddings
    if emb_size != vocab_size:
        model.resize_token_embeddings(vocab_size)
    return vocab_size - emb_size
