from __future__ import annotations

import math
from pathlib import Path
from typing import Any, Optional

import matplotlib.pyplot as plt
import pandas as pd


def history_to_dataframe(trainer: Any) -> pd.DataFrame:
    history = getattr(getattr(trainer, "state", None), "log_history", None) or []
    rows = []
    for row in history:
        rows.append(
            {
                "step": row.get("step"),
                "loss": row.get("loss"),
                "eval_loss": row.get("eval_loss"),
                "epoch": row.get("epoch"),
            }
        )
    return pd.DataFrame(rows)


def plot_and_save_line(
    df: pd.DataFrame,
    x: str,
    y: str,
    title: str,
    filename: str,
    output_dir: str | Path = "./sft_output/plots",
) -> str:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / filename

    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.plot(df[x], df[y])
    ax.set_title(title)
    ax.set_xlabel(x)
    ax.set_ylabel(y)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return str(path)


def plot_compare_eval_loss(
    df_base: pd.DataFrame,
    df_pack: pd.DataFrame,
    output_dir: str | Path = "./sft_output/plots",
    filename: str = "baseline_vs_packing_eval_loss.png",
) -> Optional[str]:
    if df_base.empty or df_pack.empty:
        return None

    base_eval = df_base[df_base["eval_loss"].notna()][["step", "eval_loss"]].copy()
    pack_eval = df_pack[df_pack["eval_loss"].notna()][["step", "eval_loss"]].copy()
    if base_eval.empty or pack_eval.empty:
        return None

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / filename

    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.plot(base_eval["step"], base_eval["eval_loss"], label="baseline")
    ax.plot(pack_eval["step"], pack_eval["eval_loss"], label="packing")
    ax.set_title("Baseline vs packing: eval loss")
    ax.set_xlabel("step")
    ax.set_ylabel("eval_loss")
    ax.grid(True, alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return str(path)


def build_runtime_comparison_table(
    train_res_baseline: Any,
    train_res_packing: Any,
    base_eval_loss: float | None,
    base_ppl: float | None,
    pack_eval_loss: float | None,
    pack_ppl: float | None,
) -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "run": "baseline",
                "train_runtime": getattr(train_res_baseline, "metrics", {}).get("train_runtime"),
                "train_steps_per_second": getattr(train_res_baseline, "metrics", {}).get("train_steps_per_second"),
                "eval_loss": base_eval_loss,
                "perplexity": base_ppl,
            },
            {
                "run": "packing",
                "train_runtime": getattr(train_res_packing, "metrics", {}).get("train_runtime"),
                "train_steps_per_second": getattr(train_res_packing, "metrics", {}).get("train_steps_per_second"),
                "eval_loss": pack_eval_loss,
                "perplexity": pack_ppl,
            },
        ]
    )


def render_sweep_heatmap(
    sweep_df: pd.DataFrame,
    output_dir: str | Path = "./sft_output/plots",
    filename: str = "sweep_heatmap_ppl.png",
) -> Optional[str]:
    if sweep_df.empty or "lr" not in sweep_df.columns or "accum" not in sweep_df.columns or "perplexity" not in sweep_df.columns:
        return None

    pivot = sweep_df.pivot(index="accum", columns="lr", values="perplexity")
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / filename

    fig, ax = plt.subplots(figsize=(8, 5))
    im = ax.imshow(pivot.values, aspect="auto")
    ax.set_xticks(range(len(pivot.columns)))
    ax.set_xticklabels([str(x) for x in pivot.columns], rotation=45, ha="right")
    ax.set_yticks(range(len(pivot.index)))
    ax.set_yticklabels([str(x) for x in pivot.index])
    ax.set_xlabel("learning_rate")
    ax.set_ylabel("grad_accum_steps")
    ax.set_title("Sweep perplexity heatmap")
    fig.colorbar(im, ax=ax)
    fig.tight_layout()
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return str(path)


def safe_perplexity(eval_loss: float | None) -> float | None:
    if eval_loss is None:
        return None
    if eval_loss > 100:
        return float("inf")
    return math.exp(eval_loss)


def update_results_json_extended(
    base_results: dict[str, Any],
    train_res_baseline: Any,
    train_res_packing: Any,
    sweep_best: dict[str, Any] | None,
) -> dict[str, Any]:
    results = dict(base_results)
    results["baseline_runtime"] = getattr(train_res_baseline, "metrics", {})
    results["packing_runtime"] = getattr(train_res_packing, "metrics", {})
    if sweep_best is not None:
        results["best_sweep"] = sweep_best
    return results
