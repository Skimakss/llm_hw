from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from datasets import load_dataset
from transformers import AutoTokenizer

from .config import DataConfig, ModelConfig
from .data import (
    PreparedData,
    analyze_tool_use,
    build_augmentation_report,
    build_multi_turn,
    convert_to_messages,
    dataset_to_datasetdict,
    maybe_inject_tool_use,
    seed_everything,
    summarize_tool_stats,
)
from .tokenizer_utils import (
    PreparedTokenizer,
    add_missing_tool_tokens,
    apply_chat_template_map,
    ensure_padding_token,
    pad_vocab_to_multiple,
)


def prepare_data_pipeline(cfg: DataConfig) -> PreparedData:
    seed_everything(cfg.seed)

    raw = load_dataset(cfg.dataset_name, split="train")
    formatted: list[dict[str, Any]] = []

    for item in raw:
        conv = convert_to_messages(item)
        if conv is not None:
            formatted.append(conv)
        if len(formatted) >= cfg.num_samples:
            break

    existing_tool_examples, tool_format_stats = analyze_tool_use(formatted)
    multi_turn = build_multi_turn(formatted, target_dialogues=cfg.multi_turn_dialogues)
    augmented = formatted + multi_turn
    augmented = [maybe_inject_tool_use(ex, prob=cfg.tool_injection_prob) for ex in augmented]

    dataset_messages = dataset_to_datasetdict(augmented, val_ratio=cfg.val_ratio)
    tool_stats = summarize_tool_stats(formatted, existing_tool_examples, tool_format_stats)
    augmentation_report = build_augmentation_report(
        formatted, existing_tool_examples, multi_turn, augmented
    )

    return PreparedData(
        formatted=formatted,
        augmented=augmented,
        dataset_messages=dataset_messages,
        tool_stats=tool_stats,
        augmentation_report=augmentation_report,
    )


def prepare_tokenizer_pipeline(cfg: ModelConfig) -> PreparedTokenizer:
    tokenizer = AutoTokenizer.from_pretrained(cfg.model_name, trust_remote_code=cfg.trust_remote_code)
    ensure_padding_token(tokenizer)
    added_tool_tokens = add_missing_tool_tokens(tokenizer)
    added_padding_tokens = pad_vocab_to_multiple(
        tokenizer,
        multiple_of=cfg.resize_vocab_to_multiple_of,
    )
    return PreparedTokenizer(
        tokenizer=tokenizer,
        added_tool_tokens=added_tool_tokens,
        added_padding_tokens=added_padding_tokens,
    )


def render_dataset_with_chat_template(dataset_messages: Any, tokenizer: Any) -> Any:
    return dataset_messages.map(
        lambda ex: apply_chat_template_map(ex, tokenizer),
        remove_columns=["messages"],
    )
