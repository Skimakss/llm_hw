from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

from .constants import SYSTEM_PROMPT


def ensure_padding_token(tokenizer: Any) -> None:
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
        tokenizer.pad_token_id = tokenizer.eos_token_id


def extract_tool_tokens_from_template(tokenizer: Any) -> list[str]:
    if not getattr(tokenizer, "chat_template", None):
        return []
    xml_tags = re.findall(r"</?(\w+)[^>]*>", tokenizer.chat_template)
    tool_related_keywords = ("tool_call", "tool_response", "tool_result")
    tool_tags: set[str] = set()
    for tag in xml_tags:
        if any(keyword in tag.lower() for keyword in tool_related_keywords):
            tool_tags.add(f"<{tag}>")
            tool_tags.add(f"</{tag}>")
    return sorted(tool_tags)


def add_missing_tool_tokens(tokenizer: Any, fallback: list[str] | None = None) -> list[str]:
    required_tool_tokens = extract_tool_tokens_from_template(tokenizer)
    if not required_tool_tokens:
        required_tool_tokens = fallback or [
            "<tool_call>",
            "</tool_call>",
            "<tool_response>",
            "</tool_response>",
        ]

    tokens_to_add: list[str] = []
    for token in required_tool_tokens:
        token_id = tokenizer.convert_tokens_to_ids(token)
        if token_id is None:
            tokens_to_add.append(token)
            continue
        decoded = tokenizer.decode([token_id])
        if token not in decoded:
            tokens_to_add.append(token)

    if tokens_to_add:
        tokenizer.add_special_tokens({"additional_special_tokens": tokens_to_add})
    return tokens_to_add


def pad_vocab_to_multiple(tokenizer: Any, multiple_of: int = 128) -> list[str]:
    vocab_size = len(tokenizer)
    target_size = ((vocab_size + multiple_of - 1) // multiple_of) * multiple_of
    pad_count = target_size - vocab_size
    if pad_count <= 0:
        return []
    extra_tokens = [f"<|pad_extra_{i}|>" for i in range(pad_count)]
    tokenizer.add_tokens(extra_tokens, special_tokens=True)
    return extra_tokens


def apply_chat_template_map(example: dict[str, Any], tokenizer: Any) -> dict[str, str]:
    try:
        text = tokenizer.apply_chat_template(
            example["messages"],
            tokenize=False,
            add_generation_prompt=False,
        )
        return {"text": text}
    except Exception:
        parts = [f"<|{msg['role']}|>\n{msg.get('content', '')}" for msg in example["messages"]]
        return {"text": "\n".join(parts)}


def format_generation_messages(prompt: str) -> list[dict[str, str]]:
    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": prompt},
    ]


def naive_tokenize(text: str, tokenizer: Any) -> list[int]:
    vocab = tokenizer.get_vocab()
    return [vocab.get(word, -1) for word in text.split()]


def inspect_tokenization(text: str, tokenizer: Any) -> dict[str, Any]:
    token_ids = tokenizer.encode(text, add_special_tokens=True)
    tokens = tokenizer.convert_ids_to_tokens(token_ids)
    decoded_text = tokenizer.decode(token_ids, skip_special_tokens=False)
    return {
        "text": text,
        "token_ids": token_ids,
        "tokens": tokens,
        "decoded_text": decoded_text,
        "naive_ids": naive_tokenize(text, tokenizer),
    }


@dataclass(slots=True)
class PreparedTokenizer:
    tokenizer: Any
    added_tool_tokens: list[str]
    added_padding_tokens: list[str]
