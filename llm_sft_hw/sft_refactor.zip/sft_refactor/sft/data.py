from __future__ import annotations

import json
import random
from dataclasses import dataclass
from typing import Any, Optional

import numpy as np
import torch
from datasets import Dataset, DatasetDict
from sklearn.model_selection import train_test_split

from .constants import SYSTEM_PROMPT, TOOLS


def seed_everything(seed: int = 42) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def convert_to_messages(item: dict[str, Any]) -> Optional[dict[str, Any]]:
    if "messages" in item:
        return {"messages": item["messages"]}

    if "instruction" in item and ("output" in item or "response" in item):
        resp = item.get("output") or item.get("response")
        return {
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": item["instruction"]},
                {"role": "assistant", "content": resp},
            ]
        }

    if "prompt" in item and ("completion" in item or "output" in item):
        resp = item.get("completion") or item.get("output")
        return {
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": item["prompt"]},
                {"role": "assistant", "content": resp},
            ]
        }

    if "conversations" in item:
        messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        for turn in item["conversations"]:
            role = "user" if turn.get("from") in {"human", "user"} else "assistant"
            messages.append({"role": role, "content": turn.get("value", "")})
        return {"messages": messages}

    return None


def build_multi_turn(
    samples: list[dict[str, Any]],
    target_dialogues: int = 20,
) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    idx = 0
    while len(result) < target_dialogues and idx + 1 < len(samples):
        a = samples[idx]["messages"]
        b = samples[idx + 1]["messages"]
        if len(a) >= 3 and len(b) >= 3:
            dialog = [
                {"role": "system", "content": SYSTEM_PROMPT},
                a[1],
                a[2],
                b[1],
                b[2],
            ]
            result.append({"messages": dialog})
        idx += 2
    return result


def maybe_inject_tool_use(
    example: dict[str, Any],
    prob: float = 0.15,
) -> dict[str, Any]:
    if random.random() > prob:
        return example

    messages = list(example["messages"])
    if not messages or messages[-1]["role"] != "assistant":
        return example

    tool = random.choice(TOOLS)
    if tool["name"] == "get_weather":
        city = random.choice(["Москва", "Санкт-Петербург", "Казань"])
        args = {"city": city}
        result = {
            "temperature": random.randint(-5, 25),
            "condition": random.choice(["ясно", "облачно", "дождь"]),
        }
        final_answer = (
            f"В городе {city} сейчас {result['condition']}, "
            f"температура {result['temperature']}°C"
        )
    elif tool["name"] == "search":
        query = random.choice(["обучение SFT", "chat template", "перплексия"])
        args = {"query": query}
        result = {"results": f"Найдено 5 релевантных статей по запросу '{query}'"}
        final_answer = f"По запросу '{query}' найдено несколько полезных материалов."
    else:
        a, b = random.randint(1, 9), random.randint(1, 9)
        args = {"a": a, "b": b}
        result = {"sum": a + b}
        final_answer = f"Сумма {a} и {b} равна {result['sum']}"

    messages.pop()
    tool_call_json = json.dumps({"name": tool["name"], "arguments": args}, ensure_ascii=False)
    tool_result_json = json.dumps(result, ensure_ascii=False)

    messages.append(
        {"role": "assistant", "content": f"<tool_call>\n{tool_call_json}\n</tool_call>"}
    )
    messages.append(
        {"role": "tool", "content": f"<tool_response>\n{tool_result_json}\n</tool_response>"}
    )
    messages.append({"role": "assistant", "content": final_answer})
    return {"messages": messages}


def analyze_tool_use(
    formatted: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], dict[str, int]]:
    tool_roles = {"tool", "function"}
    existing_tool_examples: list[dict[str, Any]] = []
    stats = {
        "role_tool": 0,
        "tool_call_xml": 0,
        "tool_call_pipes": 0,
        "tool_response_xml": 0,
        "tool_result_pipes": 0,
        "tool_keyword": 0,
        "function_call": 0,
    }

    for ex in formatted:
        has_structural_tool = False
        for msg in ex.get("messages", []):
            role = msg.get("role", "")
            content = msg.get("content", "")

            if role in tool_roles:
                stats["role_tool"] += 1
                has_structural_tool = True

            if isinstance(content, str):
                if "<tool_call>" in content or "</tool_call>" in content:
                    stats["tool_call_xml"] += 1
                    has_structural_tool = True
                if "<tool_response>" in content or "</tool_response>" in content:
                    stats["tool_response_xml"] += 1
                    has_structural_tool = True
                if "<|tool_call|>" in content:
                    stats["tool_call_pipes"] += 1
                    has_structural_tool = True
                if "<|tool_result|>" in content:
                    stats["tool_result_pipes"] += 1
                    has_structural_tool = True
                if "function_call" in content.lower():
                    stats["function_call"] += 1
                    has_structural_tool = True
                if "tool" in content.lower() and not has_structural_tool:
                    stats["tool_keyword"] += 1

            if "tool_calls" in msg:
                has_structural_tool = True

        if has_structural_tool:
            existing_tool_examples.append(ex)

    return existing_tool_examples, stats


def dataset_to_datasetdict(
    formatted: list[dict[str, Any]],
    val_ratio: float = 0.2,
) -> DatasetDict:
    train_data, val_data = train_test_split(formatted, test_size=val_ratio, random_state=42)
    return DatasetDict(
        {
            "train": Dataset.from_list(train_data),
            "validation": Dataset.from_list(val_data),
        }
    )


def summarize_tool_stats(
    formatted: list[dict[str, Any]],
    existing_tool_examples: list[dict[str, Any]],
    stats: dict[str, int],
) -> dict[str, Any]:
    total = len(formatted)
    tool_count = len(existing_tool_examples)
    return {
        "total_examples": total,
        "tool_examples": tool_count,
        "tool_ratio": (tool_count / total) if total else 0.0,
        "formats": {k: v for k, v in stats.items() if v > 0},
    }


def build_augmentation_report(
    formatted: list[dict[str, Any]],
    existing_tool_examples: list[dict[str, Any]],
    multi_turn: list[dict[str, Any]],
    augmented: list[dict[str, Any]],
) -> dict[str, Any]:
    tool_count_after = sum(
        1
        for ex in augmented
        if any("tool_call" in msg.get("content", "") for msg in ex.get("messages", []))
    )
    return {
        "source_examples": len(formatted),
        "source_tool_examples": len(existing_tool_examples),
        "added_multi_turn": len(multi_turn),
        "augmented_examples": len(augmented),
        "tool_examples_after": tool_count_after,
        "tool_ratio_after": tool_count_after / len(augmented) if augmented else 0.0,
    }


@dataclass(slots=True)
class PreparedData:
    formatted: list[dict[str, Any]]
    augmented: list[dict[str, Any]]
    dataset_messages: DatasetDict
    tool_stats: dict[str, Any]
    augmentation_report: dict[str, Any]
