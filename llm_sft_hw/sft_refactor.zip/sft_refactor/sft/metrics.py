from __future__ import annotations

import json
import re
from typing import Any

import torch
from tqdm import tqdm

from .tokenizer_utils import format_generation_messages


def _get_model_device(model: Any) -> torch.device:
    try:
        return next(model.parameters()).device
    except StopIteration:
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def extract_json_object(text: str) -> dict[str, Any] | None:
    text = text.strip()
    if not text:
        return None

    candidates = [text]

    fenced = re.findall(r"```(?:json)?\s*(\{.*?\})\s*```", text, flags=re.DOTALL)
    candidates.extend(fenced)

    brace_blocks = re.findall(r"\{.*?\}", text, flags=re.DOTALL)
    candidates.extend(brace_blocks)

    for candidate in candidates:
        try:
            return json.loads(candidate)
        except Exception:
            continue
    return None


def generate_text(model: Any, tokenizer: Any, prompt: str, max_new_tokens: int = 128, do_sample: bool = False) -> str:
    formatted_messages = format_generation_messages(prompt)
    rendered_prompt = tokenizer.apply_chat_template(
        formatted_messages,
        tokenize=False,
        add_generation_prompt=True,
    )
    enc = tokenizer(
        rendered_prompt,
        return_tensors="pt",
        padding=False,
        truncation=True,
    )
    device = _get_model_device(model)
    enc = {k: v.to(device) for k, v in enc.items()}

    with torch.no_grad():
        out = model.generate(
            input_ids=enc["input_ids"],
            attention_mask=enc.get("attention_mask"),
            max_new_tokens=max_new_tokens,
            temperature=0.7 if do_sample else None,
            top_p=0.9 if do_sample else None,
            do_sample=do_sample,
            pad_token_id=tokenizer.pad_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )
    gen_tokens = out[0][enc["input_ids"].shape[1]:]
    return tokenizer.decode(gen_tokens, skip_special_tokens=True).strip()


def json_validity_rate(
    model: Any,
    tokenizer: Any,
    prompts: list[str],
    n: int = 100,
    robust: bool = True,
) -> float:
    valid = 0
    model.eval()
    for prompt in tqdm(prompts[:n], desc="JSON validity"):
        text = generate_text(model, tokenizer, prompt, do_sample=True)
        obj = extract_json_object(text) if robust else None
        if obj is not None:
            valid += 1
            continue
        if not robust:
            try:
                json.loads(text)
                valid += 1
            except Exception:
                pass
    return valid / max(1, min(n, len(prompts)))


def debug_json_generation(model: Any, tokenizer: Any, prompt: str) -> dict[str, Any]:
    text = generate_text(model, tokenizer, prompt, do_sample=False)
    return {
        "prompt": prompt,
        "raw_text": text,
        "parsed_json": extract_json_object(text),
    }


def function_call_em(
    model: Any,
    tokenizer: Any,
    cases: list[dict[str, Any]],
    verbose: bool = False,
) -> float:
    correct = 0
    model.eval()

    for case in tqdm(cases, desc="Function-Calling EM"):
        text = generate_text(model, tokenizer, case["prompt"], do_sample=False)
        obj = extract_json_object(text)
        if verbose:
            print({"prompt": case["prompt"], "raw": text, "parsed": obj})
        if obj is None:
            continue
        if obj.get("name") == case["expected"]["name"] and obj.get("arguments") == case["expected"]["arguments"]:
            correct += 1

    return correct / max(1, len(cases))
