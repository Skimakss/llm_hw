from dataclasses import dataclass, field


@dataclass(slots=True)
class DataConfig:
    dataset_name: str = "databricks/databricks-dolly-15k"
    num_samples: int = 1000
    val_ratio: float = 0.2
    seed: int = 42
    tool_injection_prob: float = 0.15
    multi_turn_dialogues: int = 50


@dataclass(slots=True)
class ModelConfig:
    model_name: str = "Qwen/Qwen2.5-0.5B-Instruct"
    trust_remote_code: bool = True
    use_fp16_if_cuda: bool = True
    resize_vocab_to_multiple_of: int = 128


@dataclass(slots=True)
class TrainConfig:
    num_epochs: int = 1
    learning_rate: float = 1e-6
    batch_size: int = 1
    grad_accum_steps: int = 8
    max_seq_length: int = 512
    warmup_ratio: float = 0.15
    max_grad_norm: float = 0.5
    logging_steps: int = 10
    eval_steps: int = 10
    save_steps: int = 100
    lr_scheduler_type: str = "cosine"
    report_to: str = "none"
    output_root: str = "./sft_output"


@dataclass(slots=True)
class SweepConfig:
    learning_rates: list[float] = field(default_factory=lambda: [5e-7, 1e-6, 2e-6, 5e-6])
    accumulation_steps: list[int] = field(default_factory=lambda: [2, 4])
