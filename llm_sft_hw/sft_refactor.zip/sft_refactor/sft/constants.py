SYSTEM_PROMPT = "Ты полезный AI-ассистент."

TOOLS = [
    {
        "name": "get_weather",
        "description": "Получить текущую погоду по городу",
        "parameters": {
            "type": "object",
            "properties": {
                "city": {"type": "string", "description": "Название города"},
            },
            "required": ["city"],
        },
    },
    {
        "name": "search",
        "description": "Поиск информации по текстовому запросу",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Поисковый запрос"},
            },
            "required": ["query"],
        },
    },
    {
        "name": "sum",
        "description": "Сложить два числа",
        "parameters": {
            "type": "object",
            "properties": {
                "a": {"type": "integer"},
                "b": {"type": "integer"},
            },
            "required": ["a", "b"],
        },
    },
]
