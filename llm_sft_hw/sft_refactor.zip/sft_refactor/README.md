# SFT homework refactor

Этот каталог — разбор и переупаковка ноутбука `sft-homework.ipynb` в нормальный мини‑проект.

## Что было плохо в ноутбуке

- переиспользуемые функции смешаны с одноразовыми debug-ячейками;
- есть дубли логики (`analyze_existing_tool_use` vs `analyze_tool_use_in_dataset`,
  `json_validity_rate` vs `json_validity_rate_improved`,
  `function_call_em` vs `function_call_em_improved`);
- конфиг, загрузка данных, токенизация, обучение, метрики и визуализации лежат вперемешку;
- из-за этого сложно менять гиперпараметры, повторно запускать отдельные шаги и читать код.

## Новая структура

```text
sft_refactor/
├── README.md
├── run_sft.py                  # простой точечный entrypoint
├── NOTEBOOK_TO_MODULE_MAP.md   # куда переехала каждая функция
└── sft/
    ├── __init__.py
    ├── config.py               # dataclass-конфиги
    ├── constants.py            # demo-tools и системный prompt
    ├── data.py                 # подготовка и аугментация датасета
    ├── tokenizer_utils.py      # токенизатор, tool tokens, chat template
    ├── model_utils.py          # загрузка модели и resize embeddings
    ├── training.py             # trainer, train/eval, sweep
    ├── metrics.py              # JSON validity, function-calling EM
    ├── visualization.py        # графики и сводные таблицы
    └── pipeline.py             # высокоуровневые шаги пайплайна
```

## Как этим пользоваться

### 1) Подготовить данные и токенизатор в коде

```python
from sft.config import DataConfig, ModelConfig, TrainConfig
from sft.pipeline import prepare_data_pipeline, prepare_tokenizer_pipeline

data_cfg = DataConfig()
model_cfg = ModelConfig()

prepared = prepare_data_pipeline(data_cfg)
tokenizer_bundle = prepare_tokenizer_pipeline(model_cfg)
```

### 2) Собрать trainer

```python
from sft.training import build_training_args, build_trainer
from sft.model_utils import load_model_for_sft, sync_model_embeddings_with_tokenizer

model = load_model_for_sft(model_cfg)
sync_model_embeddings_with_tokenizer(model, tokenizer_bundle.tokenizer)

args = build_training_args(
    train_cfg=TrainConfig(),
    output_dir="./sft_output/baseline",
    packing=False,
)

trainer = build_trainer(
    model=model,
    tokenizer=tokenizer_bundle.tokenizer,
    train_args=args,
    dataset=prepared.dataset_text,
)
```

### 3) Запустить весь baseline через entrypoint

```bash
python run_sft.py
```

## Что я сознательно НЕ переносил как “ядро проекта”

В ноутбуке было много чисто исследовательских ячеек:
- случайные `print(...)`;
- ad-hoc debug генераций;
- длинные поясняющие markdown-блоки;
- разовые визуальные проверки токенизатора;
- блоки, завязанные на ручной порядок выполнения notebook.

Их лучше держать в отдельном `experiments/` или уже в коротком чистом ноутбуке поверх модулей.

## Что улучшено по сравнению с ноутбуком

- дубли объединены в одну актуальную реализацию;
- конфиги вынесены в dataclass;
- в каждой функции одна ответственность;
- pipeline можно запускать по шагам, а не только сверху вниз;
- код легко тестировать по модулям;
- функции больше не зависят от скрытого глобального состояния ноутбука.
